#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'serial port class'


__author__ = 'cc'

import serial
import serial.tools.list_ports
import binascii
import logging

def serialport_list():

	port_list = list(serial.tools.list_ports.comports())

	if(len(port_list) <= 0):
		print('serial port not avaliable')
		return None
	else:
		port = [list(x) for x in port_list]
		for x in port:
			print x[0] + ' '+ x[1]
	return port

if __name__ == '__main__':
	import threading

	port_list=serialport_list()

