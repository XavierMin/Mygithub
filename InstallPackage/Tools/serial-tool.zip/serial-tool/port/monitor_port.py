#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'serial port class'


__author__ = 'cc'

import serial
import serial.tools.list_ports
import binascii
import logging
from sys import argv
import time

taskRuning = True
def serialport_Log():
	while 1:
		time.sleep(1)
		print 'print'
		# if evt.isSet():
		# 	evt.clear()
		# 	if s.recvData:
		# 		print s.recvData
		# 		s.recvData = None
		#


class Serial_port(object):
	"""docstring for serial_port"""
	def __init__(self, port=None, baudrate=115200, bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE,
		timeout=None, xonxoff=False, rtscts=False, write_timeout=None, dsrdtr=False, inter_byte_timeout=None):
		self.port = port
		self.baudrate = baudrate
		self.bytesize = bytesize
		self.parity = parity
		self.stopbits = stopbits
		self.timeout = timeout
		self.xonxoff = xonxoff
		self.rtscts = rtscts
		self.write_timeout = write_timeout
		self.dsrdtr = dsrdtr
		self.inter_byte_timeout = inter_byte_timeout
		self.device = None
		self.recvData = None
		self.alive = False
		# print self.port
		# print self.baudrate
		# print self.bytesize
		# print self.parity
		# print self.stopbits
		# print self.xonxoff
		# print self.rtscts
		# print self.dsrdtr


	def serialport_open(self):
		self.device = serial.Serial()
		self.device.port = self.port
		self.device.baudrate = self.baudrate
		self.device.bytesize = self.bytesize
		self.device.parity = self.parity
		self.device.stopbits = self.stopbits
		self.device.timeout = self.timeout
		self.device.xonxoff = self.xonxoff
		self.device.rtscts = self.rtscts
		self.device.write_timeout = self.write_timeout
		self.device.dsrdtr = self.dsrdtr
		self.device.inter_byte_timeout = self.inter_byte_timeout
		try:
			self.device.open()
			if self.device.isOpen():
				self.alive = True
				return True
		except IOError as e:
			self.alive = False
			logging.error(e)
			return False

	def serialport_close(self):
		if self.device.isOpen():
			self.alive = False
			self.device.close()

	def serialport_read(self):
		while 1:
			time.sleep(4)
			print 'read'
			# if self.alive:
			# 	try:
			# 		number = self.device.inWaiting()
			# 		if number:
			# 			self.recvData = self.device.read(number)
			# 			evt.set()
			# 	except IOError as e:
			# 		logging.error(e)
			#

	def serialport_write(self, data, isHex):
		if self.alive:
			if isHex:
				data = binascii.unhexlify(data)
			self.device.write(data)
			self.device.flush()

if __name__ == '__main__':
	import threading
	evt = threading.Event()

	if len(argv) < 2:
	    print 'too few arguments'
	else:
		s=Serial_port(argv[1].lower())
		s.serialport_open()
		serialRead = threading.Thread(target = s.serialport_read)
		serialPortLog = threading.Thread(target = serialport_Log)
		serialRead.setDaemon(True)
		serialRead.start()
		serialPortLog.setDaemon(True)
		serialPortLog.start()
		serialRead.join()
		serialPortLog.join()
			#s.serialport_close()
